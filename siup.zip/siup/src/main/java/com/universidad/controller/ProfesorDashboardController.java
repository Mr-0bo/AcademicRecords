package main.java.com.universidad.controller;

public class ProfesorDashboardController {
}
