# Explicación del Diagrama de Nivel 1

## Objetivo del diagrama

El diagrama de nivel 1 detalla los subprocesos internos del sistema. Muestra con más precisión cómo se autentica un usuario, cómo el administrador registra información académica, cómo se capturan calificaciones y cómo el alumno consulta sus resultados.

## Flujo de autenticación

1. El usuario ingresa correo y contraseña.
2. El sistema valida que los campos no estén vacíos.
3. Se busca el usuario por correo en la base de datos.
4. Se verifica la contraseña mediante BCrypt.
5. Si el acceso es correcto, se crea la sesión y se redirige según el rol: administrador, profesor o alumno.

## Flujo administrativo

El administrador puede registrar o editar alumnos, profesores, carreras y materias. Para alumnos y profesores, el sistema guarda datos generales en la tabla de usuarios y datos específicos en las tablas correspondientes.

## Flujo de grupos e inscripciones

El sistema permite asociar una materia con un profesor y un periodo para formar un grupo. Después, el alumno puede ser inscrito al grupo. Al crear la inscripción, se genera un registro inicial de calificación en cero para preparar la captura posterior.

## Flujo de configuración de evaluación

El administrador registra los porcentajes de evaluación y la calificación mínima. Antes de guardar, el sistema valida que los porcentajes sumen 100%. Si no cumplen, se rechaza la configuración.

## Flujo de captura y cálculo de calificaciones

1. El profesor selecciona un grupo.
2. El sistema carga alumnos inscritos y calificaciones existentes.
3. El profesor captura parcial 1, parcial 2, parcial 3, actividades y proyecto.
4. El sistema valida que cada calificación esté entre 0 y 10.
5. Se consulta la configuración de evaluación de la materia.
6. Se calcula el promedio final.
7. Se compara el promedio contra la calificación mínima.
8. Se guarda la calificación actualizada.

## Flujo de consulta del alumno

El alumno solicita sus calificaciones. El sistema consulta sus inscripciones y después obtiene las calificaciones asociadas. Finalmente muestra parciales, actividades, proyecto, promedio final y estatus.

## Interpretación

Este diagrama es el más detallado. Sirve para explicar cómo se transforma la información desde que entra al sistema hasta que queda almacenada o se muestra como resultado al usuario.
