# Descripción del proyecto analizado

## Proyecto
Sistema de escritorio desarrollado con **JavaFX** para la administración y consulta de calificaciones universitarias.

## Elementos identificados en el archivo fuente

El proyecto contiene una arquitectura por capas:

- **Capa de presentación:** controladores JavaFX y vistas FXML.
- **Capa de servicios:** `AuthService`, `AdminService` y `EvaluacionService`.
- **Capa de repositorios:** acceso a datos mediante repositorios especializados.
- **Capa de persistencia:** base de datos local **SQLite**.
- **Modelo:** entidades como `Usuario`, `Alumno`, `Profesor`, `Carrera`, `Materia`, `Grupo`, `Inscripcion`, `ConfiguracionEvaluacion` y `Calificacion`.

## Roles principales

1. **Administrador:** administra alumnos, profesores, carreras y materias. El código también contempla grupos, inscripciones, configuración de evaluación y edición de calificaciones mediante servicios/repositorios.
2. **Profesor:** consulta sus grupos, captura calificaciones, calcula promedio final y guarda el resultado.
3. **Alumno:** consulta sus calificaciones, promedio final y estatus.

## Regla principal de evaluación

El promedio final se calcula con base en tres parciales, actividades y proyecto, usando los porcentajes definidos para cada materia. Después se compara contra la calificación mínima para marcar el estatus como **Aprobado** o **Reprobado**.

## Nota técnica

Los diagramas se realizaron como **DFD / Diagramas de Flujo de Datos**. Se representan:

- **Entidades externas:** actores que interactúan con el sistema.
- **Procesos:** funciones o módulos que transforman información.
- **Almacenes de datos:** tablas o conjuntos lógicos persistidos en SQLite.
- **Flujos de datos:** información que entra, se procesa o sale del sistema.
